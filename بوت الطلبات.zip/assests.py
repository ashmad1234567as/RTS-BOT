import discord

# Embeds
class embeds:
    def __init__(self):
        pass
    def embed1():
        embed = discord.Embed(
            title= "**لإرسال طلب اكتب طلبك هنا ⬇️ **",
            color=discord.Colour.dark_blue()
        )
        return embed
    def embed2(order, thumbnail, author_name, author_icon, footer):
        embed = discord.Embed(
            title= "** اختر نوع طلبك: **",
            description= f"""\n**طلبك:**\n
```order```\n\n""".replace('order', order),
        color=discord.Colour.dark_blue()
        )
        embed.set_author(name= author_name, icon_url=author_icon)
        embed.set_thumbnail(url=thumbnail)
        embed.set_footer(text=footer)
        return embed
    def order_embed(order, type, thumbnail, author_name, author_icon, footer):
        embed = discord.Embed(
            description=f"** طلب {type}:**\n\n```{order}```",
            color=discord.Colour.dark_blue()
        )
        embed.set_author(name= author_name, icon_url=author_icon)
        embed.set_thumbnail(url=thumbnail)
        embed.set_footer(text=footer)
        return embed
# Messages 

class messages:
    def __init__(self):
        self.messages = {
            "not_admin": "**You are not an admin!**",
            "order_set": "** تم تعيين روم استقبال الطلبات إلى channel **",
            "post_set" : "** تم تعيين روم نشر الطلبات إلى channel **",
            "cat_added": "** تمت إضافة نوع الطلب type**",
        }
    def get(self, msg):
        return self.messages[msg]
