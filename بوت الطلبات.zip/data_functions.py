from asyncio import FastChildWatcher
import json as js


class json_database:
    def __init__(self, db_file):
        self.db_file = db_file

    def set(self, value, key):
        with open(self.db_file, 'r') as data_r:
            data_j = js.load(data_r)
            data_r.close()
        data_j[key] = value
        with open(self.db_file, 'w') as data_w:
            data_w.write(js.dumps(data_j, indent=4))
            data_w.close()
        return True

    def get(self, key):
        with open(self.db_file, 'r') as data_r:
            data_j = js.load(data_r)
            data_r.close()
        return data_j[key]    
    
    def append(self, list, value):
        with open(self.db_file, 'r') as data_r:
            data_j = js.load(data_r)
            data_r.close()
        if value not in data_j[list]:
            data_j[list].append(value)
        else:
            return False
        with open(self.db_file, 'w') as data_w:
            data_w.write(js.dumps(data_j, indent=4))
            data_w.close()
        return True       

    def remove(self, list, value):
        with open(self.db_file, 'r') as data_r:
            data_j = js.load(data_r)
            data_r.close()
        try:
            data_j[list].remove(value)
        except:
            return False
        with open(self.db_file, 'w') as data_w:
            data_w.write(js.dumps(data_j, indent=4))
            data_w.close()
        return True

    def reset(self):
        with open(self.db_file, 'r') as data_r:
            data_j = js.load(data_r)
            data_r.close()
            data_j['order_channel'] = None
            data_j['post_channel'] = None
            data_j['categories'].clear()
        with open(self.db_file, 'w') as data_w:
            data_w.write(js.dumps(data_j, indent=4))
            data_w.close()
        return True