import discord
from discord.ext import tasks
from discord import app_commands
from discord.ext import commands
import asyncio
from dotenv import load_dotenv, find_dotenv
import os
from datetime import datetime
import json
import pytz
from data_functions import json_database
from assests import embeds, messages
load_dotenv(find_dotenv())
token= os.getenv('TOKEN')

@tasks.loop(seconds=1)
async def day_loop():
    guild = discord.Object(id=1020044841922609313)
    zone = pytz.timezone('Africa/Cairo')
    now = datetime.now(zone)
    if now.hour == 11:
        await bot.get_channel(db.get('order_channel')).send(embed=embeds.embed1())
        await asyncio.sleep(60*61)

bot = commands.Bot(command_prefix="-", intents=discord.Intents.all())
db  = json_database('database.json')
replies = messages()
class abot(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.all())
        self.synced = False

    async def on_ready(self):
        await tree.sync()
        self.synced = True
        print(f"Bot is online as {bot.user.display_name}")
        activity = discord.Game(name= f"Testing... in {bot.guilds[0].name}", type=3)
        await bot.change_presence(status=discord.Status.do_not_disturb, activity=activity)
bot = abot()
tree= app_commands.CommandTree(bot)

# Commands 
@tree.command(name="orders_set", description="تحديد روم الطلبات")
async def self(interaction: discord.Interaction, channel:discord.TextChannel):
    # Admin check
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(replies.get('not_admin'), ephemeral=True)
        return
    if db.set(key='order_channel', value=channel.id):
        await interaction.response.send_message(replies.get('order_set').replace('channel', f'<#{channel.id}>'))
        return

@tree.command(name="post_set", description="تحديد روم نشر الطلبات")
async def self(interaction: discord.Interaction, channel:discord.TextChannel):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(replies.get('not_admin'), ephemeral=True)
        return
    if db.set(key='post_channel', value=channel.id):
        await interaction.response.send_message(replies.get('post_set').replace('channel', f'<#{channel.id}>'))
        return

@tree.command(name="add_category", description="إضافة نوع طلب")
async def self(interaction: discord.Interaction, name:str):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(replies.get('not_admin'), ephemeral=True)
        return
    if db.append(list="categories", value=name):
        await interaction.response.send_message(replies.get('cat_added').replace('type', f"`{name}`"))
        await interaction.channel.send(f"```{db.get('categories')}```")
        return

@tree.command(name="send_embed", description="ارسال امبد الطلبات في روم الطلبات")
async def self(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(replies.get('not_admin'), ephemeral=True)
        return
    channel_id = db.get('order_channel')
    await interaction.guild.get_channel(db.get('order_channel')).send(embed=embeds.embed1())
    await interaction.response.send_message("Done")

@tree.command(name="start_loop")
async def self(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(replies.get('not_admin'), ephemeral=True)
        return
    day_loop.start()
    await interaction.response.send_message("Done")
@tree.command(name="stop_loop")
async def self(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(replies.get('not_admin'), ephemeral=True)
        return
    day_loop.stop()
    await interaction.response.send_message("Done")
@tree.command(name="reset")
async def self(interaction: discord.Interaction):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(replies.get('not_admin'), ephemeral=True)
        return
    db.reset()
    await interaction.response.send_message("Done")


class Select(discord.ui.Select):
    def load_options(self):
        options = []
        self.emoji = emoji
        for option in db.get('categories'):
            options.append(discord.SelectOption(label=option, emoji=self.emoji))
        return options
    def __init__(self):
        options= self.load_options()
        super().__init__(placeholder="Select Manu", max_values=1, min_values=1, options=options)
    # Menu Callback
    async def callback(self, interaction:discord.Interaction):
        await interaction.response.send_message("** <@userid> | تم إرسال طلبك:\n```order```\nفي روم channel **".replace("order", order).replace("channel", f"<#{db.get('post_channel')}>").replace('userid', str(interaction.user.id)), ephemeral=True)
        embed = embeds.order_embed(
            order=order,
            type=self.values[0],
            thumbnail=interaction.user.display_avatar,
            author_name=interaction.user.display_name,
            author_icon=interaction.user.display_avatar,
            footer= f'{bot.user.display_name} | Developed By: EmAitch#0004'
        )
        await interaction.guild.get_channel(db.get('post_channel')).send("** طلب جديد من: <@userid>\nلـ mention **".replace('userid', str(interaction.user.id)).replace('mention', "<@&1016684253112709130>"), embed=embed)
        await menu.delete()

class SelectView(discord.ui.View):
    def __init__(self, *, timeout= 180):
        super().__init__(timeout=timeout)
        self.add_item(Select())

@bot.event
async def on_message(ctx:discord.Message):
    if ctx.author.id == bot.user.id:
        return 
    if ctx.channel.id != db.get('order_channel'):
        return
    global menu, order, emoji
    emoji = await ctx.guild.fetch_emoji(1022375340250775662)
    order = ctx.content
    embed = embeds.embed2(
        order=ctx.content,
        thumbnail=bot.user.display_avatar,
        author_name=ctx.author.display_name,
        author_icon=ctx.author.display_avatar,
        footer=f'{bot.user.display_name} | Developed By: EmAitch#0004'
    )
    menu = await ctx.channel.send(embed=embed, view=SelectView(), delete_after=30)
    await ctx.delete()
    

bot.run(token)